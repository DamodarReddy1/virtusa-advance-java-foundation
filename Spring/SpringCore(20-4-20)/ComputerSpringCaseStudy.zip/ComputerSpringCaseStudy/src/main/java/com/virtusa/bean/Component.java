/**
 * 
 */
package com.virtusa.bean;

/**
 * @author Damodar Reddy7:29:46 PMApr 19, 2020
 * Component.java
 */
interface Component {
	void getPrice();
}
