/**
 * 
 */
package com.virtusa.bean;

import java.util.ArrayList;
import java.util.List;


/**
 * @author Damodar Reddy7:14:10 PMApr 19, 2020
 * Composite.java
 */
public class Composite implements Component {
	String name;
	List<Component> components;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Component> getComponents() {
		return components;
	}
	public void setComponents(List<Component> components) {
		this.components = components;
	}



	public Composite(String name) {
		super();
		this.name = name;
	}
	@Override
	public void getPrice() {
		System.out.println(name);
		for (Component c:components)
		{
			c.getPrice();
		}

	}
	public Composite() {
		super();

	}
}
