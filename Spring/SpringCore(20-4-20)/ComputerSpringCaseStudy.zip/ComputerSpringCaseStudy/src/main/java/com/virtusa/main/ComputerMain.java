/**
 * 
 */
package com.virtusa.main;
import com.virtusa.bean.Composite;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class ComputerMain {
	public static void main(String[] args) {

		@SuppressWarnings("resource")
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-config.xml");
		Composite computer= (Composite) applicationContext.getBean("computer");
		computer.getPrice();
	}
}
