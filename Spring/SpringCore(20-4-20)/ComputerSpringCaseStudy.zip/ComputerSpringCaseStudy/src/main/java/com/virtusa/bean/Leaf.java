/**
 * 
 */
package com.virtusa.bean;


/**
 * @author Damodar Reddy7:32:07 PMApr 19, 2020
 * Leaf.java
 */
public class Leaf implements Component
{

	int price;
	String name;
	
	@Override
	public void getPrice() {
		System.out.println(name);
		System.out.println(price);
	}
	public Leaf(int price, String name) {
		super();
		this.price = price;
		this.name = name;
	}
	public Leaf() {
		super();

	}
}
